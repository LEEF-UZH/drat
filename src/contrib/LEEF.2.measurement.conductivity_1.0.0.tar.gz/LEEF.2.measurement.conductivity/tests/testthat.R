library(testthat)
library(LEEF.measurement.conductivity)

test_check("LEEF.measurement.conductivity")
