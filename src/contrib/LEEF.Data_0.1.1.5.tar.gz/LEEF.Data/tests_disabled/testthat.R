library(testthat)
library(LEEF.Data)

test_check(
  "LEEF.Data"
)

