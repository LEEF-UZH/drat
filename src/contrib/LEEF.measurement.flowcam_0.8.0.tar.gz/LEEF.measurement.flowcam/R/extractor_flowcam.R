#' Preprocessor flowcam data
#'
#' extract data from all \code{*_classes_*_data.csv} files
#'
#' @param input directory from which to read the data
#' @param output directory to which to write the data
#'
#' @return invisibly \code{TRUE} when completed successful
#'
#' @importFrom data.table fread
#' @importFrom	stats sd
#'
#' @export
extractor_flowcam <- function( input, output ) {
  message("\n########################################################\n")
  message("\nExtracting flowcam...\n")

# Based on flowcam_classification_to_final_data.R ----------------------------------------
  # David Inauen, 19.06.2017

# Get flowcam directory names ------------------------------------------------------

  flowcam_path <- file.path( input, "flowcam" )
  trait_files <- list.files(
    path = flowcam_path,
    pattern = "\\.csv$",
    recursive = TRUE,
    full.names = FALSE
  )
  trait_files <- grep(
    pattern = "_summary.csv",
    trait_files,
    value = TRUE,
    invert = TRUE
  )

  metadata_files <- list.files(
    path = flowcam_path,
    pattern = "_summary\\.txt$",
    recursive = TRUE,
    full.names = FALSE
  )

  if (length(trait_files) != length(metadata_files)) {
    message("ERROR - unequal number of trait and metadata files. Processing Aborted!!!\n")
    message("\n########################################################\n")
    return(invisible(FALSE))
  }

  if (length(trait_files) == 0) {
    message("nothing to extract\n")
    message("\n########################################################\n")
    return(invisible(FALSE))
  }

  # read in traits ----------------------------------------------------------

  traits <- lapply(
    file.path(flowcam_path, trait_files),
    data.table::fread
  )

  # traits <- dplyr::bind_rows(traits)
  traits <- do.call( rbind.data.frame, traits )


  colnames(traits) <- c(
    "Particle_ID",
    "Area_ABD", "Area_Filled",
    "Aspect_Ratio", "Average_Blue", "Average_Green", "Average_Red",
    "Calibration_Factor", "Calibration_Image",
    "Camera",
    "Capture_X", "Capture_Y",
    "Ch1_Area", "Ch1_Peak", "Ch1_Width",
    "Ch2_Area", "Ch2_Peak", "Ch2_Width", "Ch2_Ch1_Ratio",
    "Circle_Fit", "Circularity", "Circularity_Hu",
    "Compactness",
    "Convex_Perimeter", "Convexity",
    "Date",
    "Diameter_ABD", "Diameter_ESD", "Edge_Gradient",
    "Elongation", "Feret_Angle_Max", "Feret_Angle_Min", "Fiber_Curl",
    "Fiber_Straightness", "Filter_Score", "Geodesic_Aspect_Ratio",
    "Geodesic_Length", "Geodesic_Thickness", "Image_File", "Image_Height",
    "Image_Width", "Image_X", "Image_Y", "Intensity", "Length",
    "Particles_Per_Chain", "Perimeter", "Ratio_Blue_Green", "Ratio_Red_Blue",
    "Ratio_Red_Green", "Roughness", "Scatter_Area", "Scatter_Peak", "Scatter_Width",
    "Sigma_Intensity", "Source_Image", "Sum_Intensity", "Symmetry", "Time",
    "Timestamp", "Transparency", "Volume_ABD", "Volume_ESD", "Width"
  )

  # extract information on date and microcosm from the column "Image" --------

  db <- sapply(
    traits$Image_File,
    function(x) {
      x <- strsplit(
        x,
        split = "_"
      )
      return(c(date = x[[1]][[1]], bottle = x[[1]][[2]]))
    }
  )

  traits$date <- db["date",]
  traits$bottle <- db["bottle",]

# read in metadata --------------------------------------------------------

  metadata <- lapply(
    metadata_files,
    function(x){
      db <- strsplit(
        x = dirname(x),
        split = "_"
      )[[1]]
      names(db) <- c("date", "bottle")

      # label <- gsub(x=x, pattern="\\/", replacement=" ")
      # label <- gsub(x=label, pattern="\\_", replacement=" ")
      # pieces <- strsplit(label, " ")
      # date <- sapply(pieces, "[", 4)
      # bottle <- sapply(pieces, "[", 5)

      md <- readLines( file.path( flowcam_path, x ) )
      md <- grep("\t", md, value = TRUE)
      md <- gsub( "\t", "   ", md)
      md <-  yaml::yaml.load( md  )
      md <- data.frame(
        date = db[["date"]],
        bottle = db[["bottle"]],
        parameter = names(unlist(md)),
        value = unlist(md, use.names = FALSE)
      )

      return(md)
      }
    )
  metadata <- do.call( rbind.data.frame, metadata )


  # add volume_imaged to traits ---------------------------------------------

  volume_imaged <- subset(
    metadata[c("date", "bottle", "value")],
    subset =  metadata$parameter == "Fluid Volume Imaged"
  )
  names(volume_imaged)[names(volume_imaged)=="value"] <- "volume_imaged"

  traits <- merge(
      x = traits,
      y = volume_imaged,
      by = c("date", "bottle"),
      all.x = TRUE,
      all.y = FALSE
  )

# SAVE --------------------------------------------------------------------

  add_path <- file.path( output, "flowcam" )
  dir.create( add_path, recursive = TRUE, showWarnings = FALSE )
  #
  saveRDS(
    object = traits,
    file = file.path(add_path, "algae_traits.rds")
  )
  #
  saveRDS(
    object = metadata,
    file = file.path(add_path, "algae_metadata.rds")
  )
  file.copy(
    from = file.path(input, "sample_metadata.yml"),
    to = file.path(output, "sample_metadata.yml")
  )

# Finalize ----------------------------------------------------------------

  message("done\n")
  message("\n########################################################\n")

  invisible(TRUE)
}
