library(testthat)
library(LEEF.measurement.toc)

test_check("LEEF.measurement.toc")
