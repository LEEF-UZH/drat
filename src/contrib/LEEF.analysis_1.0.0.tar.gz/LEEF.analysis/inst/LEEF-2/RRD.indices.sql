-- ####################################
-- ####################################
-- Measurement Indices
-- ####################################
-- ####################################

CREATE INDEX idx_conductivity__conductivity_timetamp on conductivity__conductivity(timestamp);
CREATE INDEX idx_conductivity__conductivity_bottle on conductivity__conductivity(bottle);
CREATE INDEX idx_conductivity__conductivity_timestamp_bottle on conductivity__conductivity(timestamp, bottle);

CREATE INDEX idx_manualcount__manualcount_density_timetamp on manualcount__manualcount_density(timestamp);
CREATE INDEX idx_manualcount__manualcount_density_bottle on manualcount__manualcount_density(bottle);
CREATE INDEX idx_manualcount__manualcount_density_timestamp_bottle on manualcount__manualcount_density(timestamp, bottle);

CREATE INDEX idx_o2meter__o2meter_timetamp on o2meter__o2meter(timestamp);
CREATE INDEX idx_o2meter__o2meter_bottle on o2meter__o2meter(bottle);
CREATE INDEX idx_o2meter__o2meter_timestamp_bottle on o2meter__o2meter(timestamp, bottle);

CREATE INDEX idx_flowcam__algae_density_timetamp on flowcam__algae_density(timestamp);
CREATE INDEX idx_flowcam__algae_density_bottle on flowcam__algae_density(bottle);
CREATE INDEX idx_flowcam__algae_density_timestamp_bottle on flowcam__algae_density(timestamp, bottle);

CREATE INDEX idx_flowcytometer__flowcytometer_density_timetamp on flowcytometer__flowcytometer_density(timestamp);
CREATE INDEX idx_flowcytometer__flowcytometer_density_bottle on flowcytometer__flowcytometer_density(bottle);
CREATE INDEX idx_flowcytometer__flowcytometer_density_timestamp_bottle on flowcytometer__flowcytometer_density(timestamp, bottle);

CREATE INDEX idx_bemovi_mag_16__mean_density_per_ml_timetamp on bemovi_mag_16__mean_density_per_ml(timestamp);
CREATE INDEX idx_bemovi_mag_16__mean_density_per_ml_bottle on bemovi_mag_16__mean_density_per_ml(bottle);
CREATE INDEX idx_bemovi_mag_16__mean_density_per_ml_timestamp_bottle on bemovi_mag_16__mean_density_per_ml(timestamp, bottle);

CREATE INDEX idx_bemovi_mag_25__mean_density_per_ml_cropped_timetamp on bemovi_mag_25__mean_density_per_ml_cropped(timestamp);
CREATE INDEX idx_bemovi_mag_25__mean_density_per_ml_cropped_bottle on bemovi_mag_25__mean_density_per_ml_cropped(bottle);
CREATE INDEX idx_bemovi_mag_25__mean_density_per_ml_cropped_timestamp_bottle on bemovi_mag_25__mean_density_per_ml_cropped(timestamp, bottle);

CREATE INDEX idx_bemovi_mag_25__mean_density_per_ml_timetamp on bemovi_mag_25__mean_density_per_ml(timestamp);
CREATE INDEX idx_bemovi_mag_25__mean_density_per_ml_bottle on bemovi_mag_25__mean_density_per_ml(bottle);
CREATE INDEX idx_bemovi_mag_25__mean_density_per_ml_timestamp_bottle on bemovi_mag_25__mean_density_per_ml(timestamp, bottle);

CREATE INDEX idx_toc__toc_timetamp on toc__toc(timestamp);
CREATE INDEX idx_toc__toc_bottle on toc__toc(bottle);
CREATE INDEX idx_toc__toc_timestamp_bottle on toc__toc(timestamp, bottle);


-- ####################################
-- ####################################
-- Traits Indices
-- ####################################
-- ####################################


CREATE INDEX idx_flowcam__algae_traits_rds_timetamp on flowcam__algae_traits_rds(timestamp);
CREATE INDEX idx_flowcam__algae_traits_rds_bottle on flowcam__algae_traits_rds(bottle);
CREATE INDEX idx_flowcam__algae_traits_rds_timestamp_bottle on flowcam__algae_traits_rds(timestamp, bottle);

CREATE INDEX idx_flowcytometer__flowcytometer_traits_algae_rds_timetamp on flowcytometer__flowcytometer_traits_algae_rds(timestamp);
CREATE INDEX idx_flowcytometer__flowcytometer_traits_algae_rds_bottle on flowcytometer__flowcytometer_traits_algae_rds(bottle);
CREATE INDEX idx_flowcytometer__flowcytometer_traits_algae_rds_timestamp_bottle on flowcytometer__flowcytometer_traits_algae_rds(timestamp, bottle);

CREATE INDEX idx_flowcytometer__flowcytometer_traits_bacteria_rds_timetamp on flowcytometer__flowcytometer_traits_bacteria_rds(timestamp);
CREATE INDEX idx_flowcytometer__flowcytometer_traits_bacteria_rds_bottle on flowcytometer__flowcytometer_traits_bacteria_rds(bottle);
CREATE INDEX idx_flowcytometer__flowcytometer_traits_bacteria_rds_timestamp_bottle on flowcytometer__flowcytometer_traits_bacteria_rds(timestamp, bottle);

CREATE INDEX idx_bemovi_mag_16__morph_mvt_timetamp on bemovi_mag_16__morph_mvt(timestamp);
CREATE INDEX idx_bemovi_mag_16__morph_mvt_bottle on bemovi_mag_16__morph_mvt(bottle);
CREATE INDEX idx_bemovi_mag_16__morph_mvt_timestamp_bottle on bemovi_mag_16__morph_mvt(timestamp, bottle);

CREATE INDEX idx_bemovi_mag_25__morph_mvt_cropped_timetamp on bemovi_mag_25__morph_mvt_cropped(timestamp);
CREATE INDEX idx_bemovi_mag_25__morph_mvt_cropped_bottle on bemovi_mag_25__morph_mvt_cropped(bottle);
CREATE INDEX idx_bemovi_mag_25__morph_mvt_cropped_timestamp_bottle on bemovi_mag_25__morph_mvt_cropped(timestamp, bottle);

CREATE INDEX idx_bemovi_mag_25__morph_mvt_timetamp on bemovi_mag_25__morph_mvt(timestamp);
CREATE INDEX idx_bemovi_mag_25__morph_mvt_bottle on bemovi_mag_25__morph_mvt(bottle);
CREATE INDEX idx_bemovi_mag_25__morph_mvt_timestamp_bottle on bemovi_mag_25__morph_mvt(timestamp, bottle);
CREATE INDEX idx_flowcam__algae_traits_rds_particle_id on flowcam__algae_traits_rds(particle_id);
CREATE INDEX idx_flowcam__algae_traits_rds_timestamp_particle_id on flowcam__algae_traits_rds(timestamp, particle_id);
CREATE INDEX idx_flowcam__algae_traits_rds_bottle_particle_id on flowcam__algae_traits_rds(bottle, particle_id);
CREATE INDEX idx_flowcam__algae_traits_rds_timestamp_bottle_particle_id on flowcam__algae_traits_rds(timestamp, bottle, particle_id);
