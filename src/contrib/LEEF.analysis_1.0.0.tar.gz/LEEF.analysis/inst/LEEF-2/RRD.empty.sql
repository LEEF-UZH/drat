-- ####################################
-- ####################################
-- Experimental Tables
-- ####################################
-- ####################################


CREATE TABLE `conductivity__conductivity` (
  `timestamp` TEXT,
  `bottle` TEXT,
  `conductivity` INTEGER
);

CREATE TABLE `composition` (
  `composition` TEXT,
  `richness` INTEGER,
  `Chlamydomonas` INTEGER,
  `Cryptomonas` INTEGER,
  `Coleps_irchel` INTEGER,
  `Colpidium` INTEGER,
  `Didinium` INTEGER,
  `Euplotes` INTEGER,
  `Loxocephallus` INTEGER,
  `Paramecium_bursaria` INTEGER,
  `Paramecium_caudatum` INTEGER,
  `Stylonychia2` INTEGER
);

CREATE TABLE `experimetal_design` (
  `bottle` TEXT,
  `incubator` TEXT,
  `temperature` TEXT,
  `resources` TEXT,
  `salinity` TEXT,
  `replicate` INTEGER
);

CREATE TABLE `stressor_levels` (
  `weekday` TEXT,
  `date` TEXT,
  `month` INTEGER,
  `week` INTEGER,
  `sampling` INTEGER,
  `temperature` REAL,
  `resources` REAL,
  `salt` REAL
);


-- ####################################
-- ####################################
-- Measurement Tables
-- ####################################
-- ####################################


CREATE TABLE `manualcount__manualcount_density` (
  `timestamp` TEXT,
  `bottle` TEXT,
  `species` TEXT,
  `ml_counted` INTEGER,
  `count` INTEGER,
  `density` REAL
);

CREATE TABLE `o2meter__o2meter` (
  `timestamp` TEXT,
  `bottle` TEXT,
  `sensor` INTEGER,
  `date` TEXT,
  `time` TEXT,
  `user` TEXT,
  `sensorid` INTEGER,
  `sensor_name` TEXT,
  `delta_t` REAL,
  `time_unit` TEXT,
  `value` REAL,
  `o2_unit` TEXT,
  `mode` TEXT,
  `phase` REAL,
  `phase_unit` TEXT,
  `amplitude` INTEGER,
  `amplitude_unit` TEXT,
  `temp` INTEGER,
  `temp_unit` TEXT,
  `pressure` REAL,
  `pressure_unit` TEXT,
  `salinity` INTEGER,
  `salinity_unit` TEXT,
  `error` INTEGER,
  `cal0` REAL,
  `cal0_unit` TEXT,
  `t0` REAL,
  `t0_unit` TEXT,
  `o2cal2nd` INTEGER,
  `o2_unit1` TEXT,
  `cal2nd` REAL,
  `cal2nd_unit` TEXT,
  `t2nd` REAL,
  `t2nd_unit` TEXT,
  `calpressure` INTEGER,
  `calpressure_unit` TEXT,
  `f1` REAL,
  `dphi1` REAL,
  `dksv1` REAL,
  `dphi2` REAL,
  `dksv2` INTEGER,
  `m` REAL,
  `cal_mode` TEXT,
  `signalledcurrent` INTEGER,
  `referenceledcurrent` INTEGER,
  `reference_amplitude` INTEGER,
  `device_serial` TEXT,
  `fwversion` TEXT,
  `sensor_type` TEXT,
  `batchid` TEXT,
  `calibration_date` INTEGER,
  `sensor_lot` INTEGER,
  `presens_calibr` INTEGER,
  `battery_voltage` REAL,
  `battery_voltage_unit` TEXT
);

CREATE TABLE `flowcam__algae_density` (
  `date_flowcam` TEXT,
  `species` TEXT,
  `bottle` TEXT,
  `temperature` TEXT,
  `salinity` TEXT,
  `replicate` INTEGER,
  `incubator` TEXT,
  `volume_imaged` REAL,
  `dilution_factor` INTEGER,
  `resources` TEXT,
  `count` INTEGER,
  `density` REAL,
  `timestamp` TEXT
);

CREATE TABLE `flowcytometer__flowcytometer_density` (
  `timestamp` TEXT,
  `plate` TEXT,
  `filename` TEXT,
  `bottle` TEXT,
  `date` TEXT,
  `sample` TEXT,
  `volume` INTEGER,
  `total.counts` INTEGER,
  `tot_density_perml` REAL,
  `specname` TEXT,
  `dilution_factor` INTEGER,
  `sample_letter` TEXT,
  `sample_number` INTEGER,
  `species` TEXT,
  `count` INTEGER,
  `density` REAL
);

CREATE TABLE `bemovi_mag_16__mean_density_per_ml` (
  `timestamp` TEXT,
  `date` TEXT,
  `species` TEXT,
  `bottle` TEXT,
  `resources` TEXT,
  `temperature` TEXT,
  `salinity` TEXT,
  `magnification` INTEGER,
  `sample` INTEGER,
  `replicate` INTEGER,
  `density` REAL
);

CREATE TABLE `bemovi_mag_25__mean_density_per_ml_cropped` (
  `timestamp` TEXT,
  `date` TEXT,
  `species` TEXT,
  `bottle` TEXT,
  `resources` TEXT,
  `temperature` TEXT,
  `salinity` TEXT,
  `magnification` INTEGER,
  `sample` INTEGER,
  `replicate` INTEGER,
  `density` REAL
);

CREATE TABLE `bemovi_mag_25__mean_density_per_ml` (
  `timestamp` TEXT,
  `date` TEXT,
  `species` TEXT,
  `bottle` TEXT,
  `resources` TEXT,
  `temperature` TEXT,
  `salinity` TEXT,
  `magnification` INTEGER,
  `sample` INTEGER,
  `replicate` INTEGER,
  `density` REAL
);

CREATE TABLE `toc__toc` (
  `filename` TEXT,
  `anaysis_time` TEXT,
  `timestamp` INTEGER,
  `bottle` TEXT,
  `position` INTEGER,
  `identification` TEXT,
  `inj_type` TEXT,
  `conc` REAL,
  `cv` REAL,
  `conc_1` REAL,
  `conc_2` REAL,
  `conc_3` REAL,
  `conc_4` REAL,
  `id` INTEGER,
  `cv_12` REAL,
  `cv_13` REAL,
  `cv_23` REAL,
  `conc_12` REAL,
  `conc_13` REAL,
  `conc_23` REAL
);


-- ####################################
-- ####################################
-- Views
-- ####################################
-- ####################################


CREATE VIEW o2
AS
SELECT
  *
FROM
  (
   SELECT
     timestamp,
     cast(
          julianday(date(substr(timestamp,1,4)||'-'||substr(timestamp,5,2)||'-'||substr(timestamp,7,2))) -
          julianday('2022-11-07') AS integer
     ) AS day,
     bottle,
     sensor,
     temp AS 'temperature_actual',
     value AS 'percent_o2',
     'o2meter' AS measurement
   FROM
     o2meter__o2meter
  )
INNER JOIN
  (
   SELECT
     *
   FROM
	 experimetal_design
  )
USING
  (bottle)
/* o2(timestamp,day,bottle,sensor,temperature_actual,percent_o2,measurement,incubator,temperature,resources,salinity,replicate) */;

CREATE VIEW toc
AS
SELECT
  *
FROM
  (
   SELECT
     timestamp,
     cast(
          julianday(date(substr(timestamp,1,4)||'-'||substr(timestamp,5,2)||'-'||substr(timestamp,7,2))) -
          julianday('2022-11-07') AS integer
     ) AS day,
     bottle,
     inj_type AS 'type',
	 conc AS 'concentration',
	 cv AS 'cv'
   FROM
     toc__toc
   WHERE
	 bottle IS NOT NULL
	)
INNER JOIN
  (
   SELECT
     *
   FROM
	   experimetal_design
  )
USING
  (bottle)
/* toc(timestamp,day,bottle,type,concentration,cv,incubator,temperature,resources,salinity,replicate) */;

CREATE VIEW conductivity
AS
SELECT
  *
FROM
  (
   SELECT
     timestamp,
     cast(
          julianday(date(substr(timestamp,1,4)||'-'||substr(timestamp,5,2)||'-'||substr(timestamp,7,2))) -
          julianday('2022-11-07') AS integer
     ) AS day,
     bottle,
     conductivity,
     'conductivity' AS measurement
   FROM
     conductivity__conductivity
  )
INNER JOIN
  (
   SELECT
     *
   FROM
	 experimetal_design
  )
USING
  (bottle)
/* conductivity(timestamp,day,bottle,conductivity,measurement,incubator,temperature,resources,salinity,replicate) */;

CREATE VIEW "density" AS
SELECT
  *
FROM
  (
   SELECT
     timestamp,
     cast( julianday(date(substr(timestamp,1,4)||'-'||substr(timestamp,5,2)||'-'||substr(timestamp,7,2))) - julianday('2022-11-07') as integer ) AS day,
     bottle,
     'bemovi_mag_16' AS measurement,
     species,
     density
   FROM
     bemovi_mag_16__mean_density_per_ml
   UNION ALL
   SELECT
     timestamp,
     cast( julianday(date(substr(timestamp,1,4)||'-'||substr(timestamp,5,2)||'-'||substr(timestamp,7,2))) - julianday('2022-11-07') as integer ) AS day,
     bottle,
     'bemovi_mag_25' AS measurement,
     species,
     density
   FROM
     bemovi_mag_25__mean_density_per_ml
   UNION ALL
   SELECT
     timestamp,
     cast( julianday(date(substr(timestamp,1,4)||'-'||substr(timestamp,5,2)||'-'||substr(timestamp,7,2))) - julianday('2022-11-07') as integer ) AS day,
     bottle,
     'bemovi_mag_25_cropped' AS measurement,
     species,
     density
   FROM
     bemovi_mag_25__mean_density_per_ml_cropped
   UNION ALL
   SELECT
     timestamp,
     cast( julianday(date(substr(timestamp,1,4)||'-'||substr(timestamp,5,2)||'-'||substr(timestamp,7,2))) - julianday('2022-11-07') as integer ) AS day,
     bottle,
     'flowcam' AS measurement,
     species,
     density
   FROM
     flowcam__algae_density
   UNION ALL
   SELECT
     timestamp,
     cast( julianday(date(substr(timestamp,1,4)||'-'||substr(timestamp,5,2)||'-'||substr(timestamp,7,2))) - julianday('2022-11-07') as integer ) AS day,
     bottle,
     'flowcytometer' AS measurement,
     species,
     density
   FROM
     flowcytometer__flowcytometer_density
   UNION ALL
   SELECT
     timestamp,
     cast( julianday(date(substr(timestamp,1,4)||'-'||substr(timestamp,5,2)||'-'||substr(timestamp,7,2))) - julianday('2022-11-07') as integer ) AS day,
     bottle,
     'manualcount' AS measurement,
     species,
     density
   FROM
     manualcount__manualcount_density
  )
INNER JOIN
  (
   SELECT
     *
   FROM
	 experimetal_design
  )
USING
  (bottle)
/* density(timestamp,day,bottle,measurement,species,density,incubator,temperature,resources,salinity,replicate) */;



-- ####################################
-- ####################################
-- Traits Tables
-- ####################################
-- ####################################


CREATE TABLE `flowcam__algae_traits_rds` (
  `particle_id` INTEGER,
  `area_abd` REAL,
  `area_filled` REAL,
  `aspect_ratio` REAL,
  `average_blue` REAL,
  `average_green` REAL,
  `average_red` REAL,
  `calibration_factor` REAL,
  `calibration_image` INTEGER,
  `camera` INTEGER,
  `capture_x` INTEGER,
  `capture_y` INTEGER,
  `ch1_area` REAL,
  `ch1_peak` REAL,
  `ch1_width` REAL,
  `ch2_area` REAL,
  `ch2_peak` REAL,
  `ch2_width` REAL,
  `ch2_ch1_ratio` REAL,
  `circle_fit` REAL,
  `circularity` REAL,
  `circularity_hu` REAL,
  `compactness` REAL,
  `convex_perimeter` REAL,
  `convexity` REAL,
  `date_flowcam` REAL,
  `diameter_abd` REAL,
  `diameter_esd` REAL,
  `edge_gradient` REAL,
  `elongation` REAL,
  `feret_angle_max` REAL,
  `feret_angle_min` REAL,
  `fiber_curl` REAL,
  `fiber_straightness` REAL,
  `filter_score` REAL,
  `geodesic_aspect_ratio` REAL,
  `geodesic_length` REAL,
  `geodesic_thickness` REAL,
  `image_file` TEXT,
  `image_height` INTEGER,
  `image_width` INTEGER,
  `image_x` INTEGER,
  `image_y` INTEGER,
  `intensity` REAL,
  `length` REAL,
  `particles_per_chain` INTEGER,
  `perimeter` REAL,
  `ratio_blue_green` REAL,
  `ratio_red_blue` REAL,
  `ratio_red_green` REAL,
  `roughness` REAL,
  `scatter_area` REAL,
  `scatter_peak` REAL,
  `scatter_width` REAL,
  `sigma_intensity` REAL,
  `source_image` INTEGER,
  `sum_intensity` REAL,
  `symmetry` REAL,
  `time` TEXT,
  `timestamp_flowcam` REAL,
  `transparency` REAL,
  `volume_abd` REAL,
  `volume_esd` REAL,
  `width` REAL,
  `bottle` TEXT,
  `volume_imaged` REAL,
  `dilution_factor` INTEGER,
  `filtration` INTEGER,
  `flowcell` TEXT,
  `instrument` INTEGER,
  `incubator` TEXT,
  `temperature` TEXT,
  `resources` TEXT,
  `salinity` TEXT,
  `replicate` INTEGER,
  `area_x` TEXT,
  `area_y` TEXT,
  `subarea` TEXT,
  `species` TEXT,
  `species_probability` REAL,
  `airbubbles_prob` REAL,
  `chlamydomonas_prob` REAL,
  `chlamydomonasclumps_prob` REAL,
  `cryptomonas_prob` REAL,
  `debris_prob` REAL,
  `digestedalgae_prob` REAL,
  `dividingchlamydomonas_prob` REAL,
  `loxocephallus_prob` REAL,
  `otherciliate_prob` REAL,
  `small_unidentified_prob` REAL,
  `timestamp` TEXT
);

CREATE TABLE `flowcytometer__flowcytometer_traits_algae_rds` (
  `sample` TEXT,
  `plate` TEXT,
  `fsc.a` REAL,
  `ssc.a` REAL,
  `fl1.a` REAL,
  `fl2.a` REAL,
  `fl3.a` REAL,
  `fl4.a` REAL,
  `fsc.h` REAL,
  `ssc.h` REAL,
  `fl1.h` REAL,
  `fl2.h` REAL,
  `fl3.h` REAL,
  `fl4.h` REAL,
  `width` REAL,
  `time` REAL,
  `timestamp` TEXT,
  `bottle` TEXT,
  `dilution_factor` INTEGER,
  `filtration` INTEGER,
  `instrument` INTEGER,
  `fixation` TEXT
);

CREATE TABLE `flowcytometer__flowcytometer_traits_bacteria_rds` (
  `sample` TEXT,
  `plate` TEXT,
  `fsc.a` REAL,
  `ssc.a` REAL,
  `fl1.a` REAL,
  `fl2.a` REAL,
  `fl3.a` REAL,
  `fl4.a` REAL,
  `fsc.h` REAL,
  `ssc.h` REAL,
  `fl1.h` REAL,
  `fl2.h` REAL,
  `fl3.h` REAL,
  `fl4.h` REAL,
  `width` REAL,
  `time` REAL,
  `timestamp` TEXT,
  `bottle` TEXT,
  `dilution_factor` INTEGER,
  `filtration` INTEGER,
  `instrument` INTEGER,
  `fixation` TEXT
);

CREATE TABLE `bemovi_mag_16__morph_mvt` (
  `timestamp` TEXT,
  `bottle` TEXT,
  `file` TEXT,
  `mean_grey` REAL,
  `sd_grey` REAL,
  `mean_area` REAL,
  `sd_area` REAL,
  `mean_perimeter` REAL,
  `sd_perimeter` REAL,
  `mean_major` REAL,
  `sd_major` REAL,
  `mean_minor` REAL,
  `sd_minor` REAL,
  `mean_ar` REAL,
  `sd_ar` REAL,
  `mean_turning` REAL,
  `sd_turning` REAL,
  `duration` REAL,
  `n_frames` INTEGER,
  `max_net` REAL,
  `net_disp` INTEGER,
  `net_speed` REAL,
  `gross_disp` REAL,
  `gross_speed` REAL,
  `max_step` REAL,
  `min_step` REAL,
  `sd_step` REAL,
  `sd_gross_speed` REAL,
  `max_gross_speed` REAL,
  `min_gross_speed` REAL,
  `id` TEXT,
  `date` TEXT,
  `magnification` INTEGER,
  `dilution_factor` INTEGER,
  `sample` INTEGER,
  `video` INTEGER,
  `incubator` TEXT,
  `temperature` TEXT,
  `resources` TEXT,
  `salinity` TEXT,
  `replicate` INTEGER,
  `species` TEXT,
  `species_probability` REAL,
  `coleps_irchel_prob` REAL,
  `colpidium_prob` REAL,
  `euplotes_prob` REAL,
  `loxocephallus_prob` REAL,
  `paramecium_bursaria_prob` REAL,
  `paramecium_caudatum_prob` REAL,
  `stylonychia2_prob` REAL
);

CREATE TABLE `bemovi_mag_25__morph_mvt_cropped` (
  `timestamp` TEXT,
  `bottle` TEXT,
  `file` TEXT,
  `mean_grey` REAL,
  `sd_grey` REAL,
  `mean_area` REAL,
  `sd_area` REAL,
  `mean_perimeter` REAL,
  `sd_perimeter` REAL,
  `mean_major` REAL,
  `sd_major` REAL,
  `mean_minor` REAL,
  `sd_minor` REAL,
  `mean_ar` REAL,
  `sd_ar` REAL,
  `mean_turning` REAL,
  `sd_turning` REAL,
  `duration` REAL,
  `n_frames` INTEGER,
  `max_net` REAL,
  `net_disp` INTEGER,
  `net_speed` REAL,
  `gross_disp` REAL,
  `gross_speed` REAL,
  `max_step` REAL,
  `min_step` REAL,
  `sd_step` REAL,
  `sd_gross_speed` REAL,
  `max_gross_speed` REAL,
  `min_gross_speed` REAL,
  `id` TEXT,
  `date` TEXT,
  `magnification` INTEGER,
  `dilution_factor` INTEGER,
  `sample` INTEGER,
  `video` INTEGER,
  `incubator` TEXT,
  `temperature` TEXT,
  `resources` TEXT,
  `salinity` TEXT,
  `replicate` INTEGER,
  `species` TEXT,
  `species_probability` REAL,
  `coleps_irchel_prob` REAL,
  `colpidium_prob` REAL,
  `cryptomonas_prob` REAL,
  `debris_and_other_prob` REAL,
  `euplotes_prob` REAL,
  `loxocephallus_prob` REAL,
  `paramecium_bursaria_prob` REAL,
  `paramecium_caudatum_prob` REAL,
  `stylonychia2_prob` REAL
);

CREATE TABLE `bemovi_mag_25__morph_mvt` (
  `timestamp` TEXT,
  `bottle` TEXT,
  `file` TEXT,
  `mean_grey` REAL,
  `sd_grey` REAL,
  `mean_area` REAL,
  `sd_area` REAL,
  `mean_perimeter` REAL,
  `sd_perimeter` REAL,
  `mean_major` REAL,
  `sd_major` REAL,
  `mean_minor` REAL,
  `sd_minor` REAL,
  `mean_ar` REAL,
  `sd_ar` REAL,
  `mean_turning` REAL,
  `sd_turning` REAL,
  `duration` REAL,
  `n_frames` INTEGER,
  `max_net` REAL,
  `net_disp` INTEGER,
  `net_speed` REAL,
  `gross_disp` REAL,
  `gross_speed` REAL,
  `max_step` REAL,
  `min_step` REAL,
  `sd_step` REAL,
  `sd_gross_speed` REAL,
  `max_gross_speed` REAL,
  `min_gross_speed` REAL,
  `id` TEXT,
  `date` TEXT,
  `magnification` INTEGER,
  `dilution_factor` INTEGER,
  `sample` INTEGER,
  `video` INTEGER,
  `incubator` TEXT,
  `temperature` TEXT,
  `resources` TEXT,
  `salinity` TEXT,
  `replicate` INTEGER,
  `species` TEXT,
  `species_probability` REAL,
  `coleps_irchel_prob` REAL,
  `colpidium_prob` REAL,
  `cryptomonas_prob` REAL,
  `debris_and_other_prob` REAL,
  `euplotes_prob` REAL,
  `loxocephallus_prob` REAL,
  `paramecium_bursaria_prob` REAL,
  `paramecium_caudatum_prob` REAL,
  `stylonychia2_prob` REAL
);
