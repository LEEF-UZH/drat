tables <- c(
  "bemovi_mag_16__mean_density_per_ml",
  "bemovi_mag_16__morph_mvt",
  "bemovi_mag_25__mean_density_per_ml",
  "bemovi_mag_25__mean_density_per_ml_cropped",
  "bemovi_mag_25__mean_density_per_ml_non_cropped",
  "bemovi_mag_25__morph_mvt",
  "bemovi_mag_25__morph_mvt_cropped",
  "bemovi_mag_25__morph_mvt_non_cropped",
  "density",
  "flowcam__algae_density",
  "flowcam__algae_traits",
  "flowcytometer__flowcytometer_density",
  "manualcount__manualcount_density",
  "o2",
  "o2meter__o2meter"
)

metadata <- dete.frame(
  table = character(0),
  column_name = character(0),
  type =
  )

for (table in tables) {
  columns <- db_read_table("~/tmp/LEEF.RRD.sqlite", table = "bemovi_mag_16__mean_density_per_ml") %>%
    collect() %>%
    names()
  for (col in columns) {
    metadata <- rbind(
      metadata,
      data.frame(
        table = table,
        column_name = col,
      )
    )
  }
}