---
title: "Untitled"
author: "Rainer M Krug"
date: "7/16/2021"
output: html_document
runtime: shiny
---




To learn more, see [Interactive Documents](http://rmarkdown.rstudio.com/authoring_shiny.html).

## Per Measurement


```{=html}
<div class="shiny-input-panel">
<div class="shiny-flow-layout">
<div>
<div class="form-group shiny-input-container">
<label class="control-label" id="measurement-label" for="measurement">Measurement:</label>
<div>
<select id="measurement"><option value="bemovi_mag_16">bemovi_mag_16</option>
<option value="bemovi_mag_25">bemovi_mag_25</option>
<option value="bemovi_mag_25_cropped">bemovi_mag_25_cropped</option>
<option value="flowcam">flowcam</option>
<option value="flowcytometer">flowcytometer</option>
<option value="manualcount">manualcount</option>
<option value="all">all</option></select>
<script type="application/json" data-for="measurement" data-nonempty="">{"plugins":["selectize-plugin-a11y"]}</script>
</div>
</div>
</div>
<div>
<div class="form-group shiny-input-container">
<label class="control-label" id="bottle-label" for="bottle">Bottle (0 = all Bottles):</label>
<input class="js-range-slider" id="bottle" data-skin="shiny" data-min="0" data-max="32" data-from="0" data-step="1" data-grid="true" data-grid-num="8" data-grid-snap="false" data-prettify-separator="," data-prettify-enabled="true" data-keyboard="true" data-data-type="number"/>
</div>
</div>
</div>
</div>
```
`<div id="out0e97016c91be16d5" class="shiny-plot-output" style="width:100%;"></div>`{=html}
