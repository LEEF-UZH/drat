#' Extractor o2meter data
#'
#' Convert all \code{.cvs} files in \code{o2meter} folder to \code{data.frame} and save as \code{.rds} file.
#'
#' This function is extracting data to be added to the database (and therefore make accessible for further analysis and forecasting)
#' from \code{.csv} files.
#'
#' @param input directory from which to read the data
#' @param output directory to which to write the data
#'
#' @return invisibly \code{TRUE} when completed successful
#'
#' @importFrom utils read.table
#' @importFrom yaml read_yaml
#'
#' @export
#'
extractor_o2meter <- function(
  input,
  output
) {
  message("\n########################################################\n")
  message("Extracting o2meter\n")

  # Get csv file names ------------------------------------------------------

  o2meter_path <- file.path( input, "o2meter" )
  fn <- list.files(
    path = o2meter_path,
    pattern = "*.csv",
    full.names = TRUE,
    recursive = TRUE
  )

  if (length(fn) == 0) {
    message("nothing to extract\n")
    message("\n########################################################\n")
    return(invisible(FALSE))
  }

  if (length(fn) > 1) {
    message("Only one file expected - aborting\n")
    message("\n########################################################\n")
    return(invisible(FALSE))
  }

  # Read file ---------------------------------------------------------------

  # to get possible encodings:
  # readr::guess_encoding(fn)

  dat <- read.delim(
    fn,
    skip = 1,
    fill = TRUE,
    fileEncoding = "ISO-8859-1"
  )

  dat[dat == "µV"] <- "microV"
  dat[dat == "°C"] <- "C"

  timestamp <- yaml::read_yaml(file.path(input, "sample_metadata.yml"))$timestamp

  dat <- cbind(timestamp = timestamp, dat)

  # SAVE --------------------------------------------------------------------

  add_path <- file.path( output, "o2meter" )
  dir.create( add_path, recursive = TRUE, showWarnings = FALSE )
  saveRDS(
    object = dat,
    file = file.path(add_path, "o2meter.rds")
  )
  file.copy(
    from = file.path(input, "sample_metadata.yml"),
    to = file.path(output, "sample_metadata.yml")
  )

  # Finalize ----------------------------------------------------------------

  message("done\n")
  message("\n########################################################\n")

  invisible(TRUE)
}
