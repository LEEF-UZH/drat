## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = FALSE,
  eval = TRUE,
  fig.retina = 4,
  ##
  plantuml.path = "./"
)
plantuml_installed <- require(plantuml)
if (plantuml_installed) {
  plantuml::plantuml_knit_engine_register()
}
library(LEEF)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  default:
#    doi: FALSE
#    tts: TRUE
#    data:
#      backend:
#  
#  master:
#    doi: FALSE
#    tts: TRUE
#    data:
#      backend:
#        mssql:
#          Database: "[database name]"
#          UID: "[user id]"
#          PWD: "[pasword]"
#          Port: 1433
#  
#  public:
#    doi: TRUE
#    tts: TRUE
#    data:
#      backend:
#        csv:
#          folder: rawData
#  
#  heatwave_e_1:
#    doi: TRUE
#    tts: TRUE
#    data:
#      backend:
#        csv:
#          folder: rawData
#  
#  heatwave:
#    doi: FALSE
#    tts: TRUE
#    data:
#      backend:
#        mysql:
#          Database: "[database name]"
#          UID: "[user id]"
#          PWD: "[pasword]"

## ----echo = TRUE, eval = FALSE------------------------------------------------
#  public_MSC_Peter:
#      from:  12.05.2019
#      until:
#      repo: LEEF.public
#  public_PhD_Mary:
#      from:  12.05.2022`
#      until:
#      repo: LEEF.public
#  heatwave_e_1:
#      from:  01.01.2019
#      until: 01.03.2019
#      repo: LEEF.heatwave.public
#  heatwave_private:
#      from:  01.01.2018
#      until: 01.01.2020
#      repo: LEEF.heatwave

## ----eval = FALSE-------------------------------------------------------------
#  source("https://bioconductor.org/biocLite.R")
#  biocLite(
#    c(
#      "flowCore"
#    )
#  )

## ----eval = FALSE-------------------------------------------------------------
#  install.packages("later")

## ----installation_prerequisites, eval = FALSE, echo = TRUE--------------------
#  install.packages("devtools")

## ----install, eval = FALSE, echo = TRUE---------------------------------------
#  devtools::install_github("rkrug/LEEF")

## ----comment=''---------------------------------------------------------------
readLines( system.file("default_config.yml", package = "LEEF") )

## ----init_db, eval = FALSE, echo = TRUE---------------------------------------
#  # library("LEEF")
#  devtools::load_all(here::here())
#  nd <- "Data_directory"
#  dir.create( nd )
#  setwd( nd )
#  file.copy(
#    from = system.file("config.yml", package = "LEEF"),
#    to = "."
#  )
#  initialize_db()

## ----import, eval = FALSE, echo = TRUE----------------------------------------
#  import_new_data()

## ----eval = FALSE-------------------------------------------------------------
#  DATA_options("to_be_imported")

## ----config_yml, eval = FALSE, echo = TRUE------------------------------------
#  default:
#    maintainer:
#      name: Max Mustermann
#      email: Max@musterfabrik.example
#    description: This is my fantastic repo
#                 with lots of data.
#  
#  master:
#    doi: FALSE
#    tts: TRUE
#    data:
#      backend:
#        mysql:
#          Database: "[database name]"
#          UID: "[user id]"
#          PWD: "[pasword]"
#          Port: 3306
#  
#  LEEF:
#    doi: TRUE
#    tts: TRUE
#    data:
#      backend:
#        sqlite:
#          folder: inst/extdata

