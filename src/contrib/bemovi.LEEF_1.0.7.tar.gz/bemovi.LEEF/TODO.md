**<span style="color:red">TODO</span>**
================

* replace architecture selection throughout

* replace ImageJ through Fiji **for all architectures** --- Possibly even Fiji docker? easier to distribute?

* Add messges to ImageJ script

* Create empty files if nothing detected instead of silently ignore


**<span style="color:green">DONE</span>**
================

*  IMPORTANT: Package expects variable to.particlelinker - NEEDS TO BE FIXED!
