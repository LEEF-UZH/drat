#' Check if data in input folder is OK and move to raw data folder
#'
#' @param input The folder, where the new files are located.
#' @param output The folder where the checked files will be moved to. A folder,
#'   which contains a subfolder called \code{bemovi}, i.e. the usually the raw data folder.
#'
#' @return \code{TRUE} if ok, \code{FALSE} or \code{list} of problems if not
#' @importFrom parallel mclapply
#' @export
#'
#' @examples
#' \dontrun{
#' raw_data_ok()
#' }
add_new_cxd <- function(input, output) {

  cxds <- list.files(
    path = input,
    pattern = ".cxd",
    full.names = TRUE
  )

  cmd <- file.path( file.path( tools_path(), "bftools", "showinf" ))
  if (is.null(cmd)) {
    stop("bftools not available in expected path!")
  }

  ok <- parallel::mclapply(
    cxds,
    function(cxd) {
      processing <- file.path(input, "bemovi", paste0("CHECKING.", cxd, ".CHECKING"))
      error <- file.path(output, "bemovi", paste0("ERROR.", cxd, ".ERROR"))
      on.exit(
        {
          if (file.exists(processing)) {
            unlink(processing)
            file.create(error)
          }
        }
      )
      ##
      file.create( processing )
      ##
      message("checking ", cxd)
      result <- list(
        ok = TRUE
      )

      # Check Filesize ----------------------------------------------------------

      result$filesize <-  file.size(cxd) == 525639680
      result$ok <- result$filesize & result$ok

      # Read metadata -----------------------------------------------------------

      arguments <-  paste(
        "-nopix",
        file.path( input, cxd ),
        sep = " "
      )
      result$metadata <- system2(
        command = cmd,
        args = arguments,
        stdout = TRUE
      )

      # Check Framerate ---------------------------------------------------------

      if (result$filesize) {
        tfl <- grep("Field \\d+ Time_From_Last", result$metadata, value = TRUE)
        tfl <- read.delim(text = tfl, sep = " ", header = FALSE)

        result$noframes = nrow(tfl) == 125
        meantfl <- sum(tfl$V4) / (nrow(tfl)-1)
        result$framerate <-  meantfl > 0.035 & meantfl <= 0.045
        result$ok <- result$filesize & result$ok
      } else {
        result$ok <- FALSE
      }

      if ( result$ok ) {
        file.copy(
          from = cxd,
          to = file.path(output, "bemovi"),
          overwrite = TRUE
        )
        unlink( cxd )
        unlink(processing)
      }
      return(result)
    }
  )
  names(ok) <- cxds
  return(ok)
}
