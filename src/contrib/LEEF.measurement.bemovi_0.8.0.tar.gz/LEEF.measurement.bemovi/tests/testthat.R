library(testthat)
library(LEEF.measurement.bemovi)

test_check("LEEF.measurement.bemovi")
