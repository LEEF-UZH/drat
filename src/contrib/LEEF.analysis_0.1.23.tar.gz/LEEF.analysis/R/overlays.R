overlays <- function(
  timestamp = 20210920,
  magnification = 25,
  cropped = FALSE,
  label = "species",
  overlay.type = "both",
  hq = FALSE,
  ffmpeg = "ffmpeg",
  mc.cores = 7
){
  library(bemovi.LEEF)
  output.dir <- "."
  mdf <- file.path(
    "./../../../../../Duck/LEEFSwift3/LEEF.archived.data/LEEF/3.archived.data/extracted",
    paste0("LEEF.bemovi.mag.", magnification, ".bemovi.", timestamp),
    "5 - merged data",
    "."
  )
  mf <- ifelse(
    cropped,
    "Master_cropped.rds",
    "Master.rds"
  )
  avivf <- file.path(
    "./../../../../../Duck/LEEFSwift3/LEEF.archived.data/LEEF/3.archived.data/pre_processed",
    paste0("LEEF.bemovi.mag.", magnification, ".bemovi.", timestamp),
    "."
  )
  fbn <- paste(
    "LEEF.bemovi.mag",
    magnification,
    ifelse(
      cropped,
      "cropped.bemovi",
      "bemovi"
    ),
    timestamp,
    sep = "."
  )

  conf <- paste(
    "bemovi_extract",
    "mag",
    magnification,
    ifelse(
      cropped,
      "cropped.yml",
      "yml"
    ),
    sep = "."
  )

  bemovi.LEEF::load_parameter(file.path(avivf, conf))

  bemovi.LEEF::create_overlays_subtitle(
    to.data = output.dir,
    merged.data.folder = mdf,
    raw.video.folder = avivf,
    temp.overlay.folder = paste(fbn, "overlay.tmp", sep = "."),
    overlay.folder = paste(fbn, "overlay", sep = "."),
    label = label,
    ffmpeg = ffmpeg,
    master = mf,
    overlay.type = overlay.type,
    hq = hq,
    mc.cores = mc.cores
  )
}
