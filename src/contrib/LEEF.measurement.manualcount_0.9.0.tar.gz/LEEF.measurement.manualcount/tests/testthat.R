library(testthat)
library(LEEF.measurement.manualcount)

test_check("LEEF.measurement.manualcount")
