packages <- list.files("./../", pattern = ".tar.gz$", full.names = TRUE, recursive = TRUE)
for (p in packages) {
  drat::insertPackage(file = p, repodir = "./../drat/")
}
