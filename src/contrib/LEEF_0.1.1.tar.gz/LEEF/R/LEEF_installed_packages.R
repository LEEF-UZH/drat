#' List packages on which LEEF depends
#'
#' This function is a wrapper around \code{tools::package_dependencies("LEEF", which = "all")}
#' @return
#' @export
#'
#' @examples
#' LEEF_installed_packages()
LEEF_installed_packages <- function() {
  tools::package_dependencies("LEEF", which = "all")
}
