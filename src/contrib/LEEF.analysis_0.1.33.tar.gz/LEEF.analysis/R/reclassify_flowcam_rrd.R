#' Title
#'
#' @param db fully qualified path to the sqlite database.
#'   If not set, defaults to option RRDdb; if this is not set, defaults to `LEEF.RRD.sqlite`
#' @param timestamp `character` vector of length 1; the timestamp to re-classify
#' @param classifier_constant `character` vector of length 1; fully qualified file name of the classifier
#'    of the constant temperature treatment, an `.rds` file
#' @param classifier_increasing `character` vector of length 1; fully qualified file name of the classifier
#'    of the increasing temperature treatment, an `.rds` file
#' @return
#'
#' @importFrom dplyr filter select %>%
#' @export
#'
#' @md
#' @examples
#'
#'
reclassify_flowcam_rrd <- function(
  db = getOption("RRDdb", "LEEF.RRD.sqlite"),
  timestamp,
  classifier_constant,
  classifier_increasing,
  species_tracked
){

# Read morph_mvt data from RRD database and remove `_prob` --------------------------------------------

  colnames <- c(
    "Particle_ID", "Area_ABD", "Area_Filled", "Aspect_Ratio", "Average_Blue",
    "Average_Green", "Average_Red", "Calibration_Factor", "Calibration_Image",
    "Camera", "Capture_X", "Capture_Y", "Ch1_Area", "Ch1_Peak", "Ch1_Width",
    "Ch2_Area", "Ch2_Peak", "Ch2_Width", "Ch2_Ch1_Ratio", "Circle_Fit",
    "Circularity", "Circularity_Hu", "Compactness", "Convex_Perimeter",
    "Convexity", "Date_Flowcam", "Diameter_ABD", "Diameter_ESD",
    "Edge_Gradient", "Elongation", "Feret_Angle_Max", "Feret_Angle_Min",
    "Fiber_Curl", "Fiber_Straightness", "Filter_Score", "Geodesic_Aspect_Ratio",
    "Geodesic_Length", "Geodesic_Thickness", "Image_File", "Image_Height",
    "Image_Width", "Image_X", "Image_Y", "Intensity", "Length", "Particles_Per_Chain",
    "Perimeter", "Ratio_Blue_Green", "Ratio_Red_Blue", "Ratio_Red_Green",
    "Roughness", "Scatter_Area", "Scatter_Peak", "Scatter_Width",
    "Sigma_Intensity", "Source_Image", "Sum_Intensity", "Symmetry",
    "Time", "Timestamp_Flowcam", "Transparency", "Volume_ABD", "Volume_ESD",
    "Width", "bottle", "volume_imaged", "dilution_factor", "filtration",
    "flowcell", "instrument", "Area_x", "Area_y", "Subarea",
    "temperature", "richness", "composition", "incubator"
  )

  algae_traits <- db_read_table(
    db = db,
    table = "flowcam__algae_traits"
  ) %>%
    dplyr::filter(timestamp == !!timestamp) %>%
    dplyr::select(dplyr::all_of(tolower(colnames))) %>%
    collect()

  # rename columns

  colnames(algae_traits) <- colnames

  algae_traits$species <- "NA"
  algae_traits$species_probability <- -1
#
#
#
#   prob <- grep("_prob", names(morph_mvt), value = TRUE)
#   prob <- c(prob, "species")
#   morph_mvt <- morph_mvt %>%
#     dplyr::select(-all_of(prob))
#
#   morph_mvt$species <- NA
#   morph_mvt$species_probability <- NA


# The classification ------------------------------------------------------


  reclassified <- LEEF.measurement.flowcam::classify(
    algae_traits = algae_traits,
    classifiers_constant = readRDS(classifier_constant),
    classifiers_increasing = readRDS(classifier_increasing),
    composition = dplyr::collect(db_read_table(db = db, table = "composition")),
    species_tracked = species_tracked
  )

  # TODO SAVE
  # algae_density
  return(invisible(reclassified))
}
