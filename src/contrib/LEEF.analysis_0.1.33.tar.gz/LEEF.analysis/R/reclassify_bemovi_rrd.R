#' Title
#'
#' @param db fully qualified path to the sqlite database.
#'   If not set, defaults to option RRDdb; if this is not set, defaults to `LEEF.RRD.sqlite`
#' @param magnification `integer` vector of length 1; magnification of the videos.
#' @param postfix `character` vector of length 1; the postfix of the tablename
#' @param timestamp `character` vector of length 1; the timestamp to re-classify
#' @param classifier_constant `character` vector of length 1; fully qualified file name of the classifier
#'    of the constant temperature treatment, an `.rds` file
#' @param classifier_inctreasing `character` vector of length 1; fully qualified file name of the classifier
#'    of the increasing temperature treatment, an `.rds` file
#'
#' @return
#'
#' @importFrom dplyr filter %>%
#' @export
#'
#' @md
#' @examples
#'
#'
reclassify_bemovi_rrd <- function(
  db = getOption("RRDdb", "LEEF.RRD.sqlite"),
  magnification,
  postfix = NULL,
  timestamp,
  classifier_constant,
  classifier_incteasing
){
stop("Not Implemented Yet!")
# Read morph_mvt data from RRD database nd remove `_prob` --------------------------------------------

  tablename <- paste0(
    "bemovi_mag_", magnification,
    "__morph_mvt", ifelse(
      is.null(postfix),
      "",
      paste0("_", postfix)
    )
  )

  morph_mvt <- db_read_table(
    db = db,
    table = tablename
  ) %>%
    dplyr::filter(timestamp == timestamp) %>%
    collect()

  prob <- grepl("_prob", names(morph_mvt))
  morph_mvt <- morph_mvt[,!prob]

  morph_mvt$species <- ""
  morph_mvt$species_probability <- -1

# The classification ------------------------------------------------------

  morph_mvt <- LEEF.measurement.bemovi::classify(
    morph_mvt = morph_mvt,
    classifiers_constant = readRDS(classifier_constant),
    classifiers_increasing = readRDS(classifier_increasing)
  )



  # -----------------------------------------------------------------------------------------------------
  # calculate species densities -------------------------------------------------------------------------

  # add temporary dummy variables in trajectory.data to be deleted afterwards

  exp_design <- read.csv("flowcam/FlowcamAnalysisScript/experimental_design.csv")

  empty_videos_ind <- which(!is.element(exp_design$file, unique(trajectory.data$file)))
  empty_videos <- exp_design[empty_videos_ind,]

  dummy_rows <- trajectory.data[1:nrow(empty_videos),]

  dummy_rows <- left_join(empty_videos, dummy_rows, by=colnames(empty_videos))
  dummy_rows$frame <- 1
  dummy_rows$species <- "dummy_species"

  trajectory.data <- rbind(trajectory.data, dummy_rows)

  # density for each frame in each sample

  extrapolation.factor <- 23.367 # to be updated
  cropping.factor <- 1 ## NEW! cropping specific

  count_per_frame <- trajectory.data %>%
    group_by(file, date, species, bottle, composition_id, temperature_treatment, magnification, sample, video, frame, dilution_factor) %>%
    summarise(count = n()) %>%
    mutate(dens.ml = count * extrapolation.factor * cropping.factor * dilution_factor)

  mean_density_per_ml <- count_per_frame %>%
    group_by(date, species, composition_id, bottle, temperature_treatment, magnification, sample) %>%
    summarise(density = sum(dens.ml)/(3*125))


  # -----------------------------------------------------------------------------------------------------
  # add density = 0 for extinct species ------------------------------------------------------------

  # magnification & cropping specific!
  # species.tracked <- c("Dexiostoma", "Loxocephallus", "Tetrahymena", "Debris_and_other", "Cryptomonas")
  species.tracked <- c("Coleps_irchel", "Colpidium", "Stylonychia1", "Stylonychia2", "Didinium", "Paramecium_caudatum", "Paramecium_bursaria", "Euplotes")


  comps <- read_csv("../../compositions.csv")
  comp_id <- unique(comps$composition)
  comps <- comps %>%
    select(tidyselect::any_of(species.tracked))

  comps.list <- apply(comps, 1, function(x){
    idx <- which(x==1)
    names(idx)
  })
  names(comps.list) <- comp_id

  mean_density_per_ml_list <- split(x = mean_density_per_ml,
                                    f = mean_density_per_ml$bottle,
                                    drop = T)

  for(i in 1:length(mean_density_per_ml_list)){
    df <- mean_density_per_ml_list[[i]]
    ID <- unique(df$composition_id)
    idx <- which(!is.element(unlist(comps.list[[ID]]), df$species))
    if(length(idx)==0) next
    for(j in idx){
      new.entry <- tail(df,1)
      new.entry$species <- comps.list[[ID]][j]
      new.entry$density <- 0
      df <- rbind(df, new.entry)
    }
    mean_density_per_ml_list[[i]] <- df
  }

  mean_density_per_ml <- do.call("rbind", mean_density_per_ml_list) %>%
    filter(species %in% species.tracked)
  morph_mvt <- morph_mvt %>%
    filter(species %in% species.tracked)
  trajectory.data <- trajectory.data %>%
    filter(species %in% species.tracked)


}
