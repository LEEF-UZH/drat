#' Title
#'
#' @param extracted
#' @param RRDB
#' @param remove_first
#'
#' @return
#'
#' @importFrom LEEF.backend.sqlite remove_data
#' @export
#'
#' @examples
add_reclassified_to_db <- function(
  dir,
  RRDB,
  remove_first = FALSE
){
  timestamps <- list.dirs(
    path = dir,
    recursive = FALSE,
    full.names = FALSE
  )

  for (timestamp in timestamps) {
    if (remove_first) {
      methods <- list.dirs(
        path = file.path(dir, timestamp),
        recursive = FALSE,
        full.names = FALSE
      )
      for (method in methods) {
        LEEF.backend.sqlite::remove_data(
          db = RRDB,
          timestamp = timestamp,
          method = method
        )
      }
    }


  #     LEEF.
  #   }
  # }

  }
}
