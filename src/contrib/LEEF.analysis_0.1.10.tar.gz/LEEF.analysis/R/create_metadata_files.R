
create_metadata_files <- function(db){
  tables <- db_read_table(db, quiet = TRUE)
  table <- tables[[1]]

  db_read_table(db = db, table = table)
}
