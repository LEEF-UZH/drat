## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----setup--------------------------------------------------------------------
#  

## -----------------------------------------------------------------------------
#  library(DBI)
#  library(RSQLite)
#  
#  dbname <- "~/LEEF/9.backend/LEEF.RRD.sqlite"

## -----------------------------------------------------------------------------
#  conn <- DBI::dbConnect(
#  	    		drv = RSQLite::SQLite(),
#  	    		dbname = dbname
#  	  		)

## -----------------------------------------------------------------------------
#  DBI::dbListTables(conn)

## -----------------------------------------------------------------------------
#  DBI::dbListFields( conn, "flowcytometer" )

## -----------------------------------------------------------------------------
#  tbl <- DBI::dbReadTable( conn, "flowcytometer")
#  head(tbl)

## -----------------------------------------------------------------------------
#  sql <- " SELECT * FROM flowcytometer"
#  
#  tbl <- DBI::dbGetQuery(
#    conn,
#    statement = sql
#  )
#  head(tbl)

## -----------------------------------------------------------------------------
#  sql <- " SELECT * FROM flowcytometer WHERE bottle = 29"
#  
#  tbl <- DBI::dbGetQuery(
#    conn,
#    statement = sql
#  )
#  head(tbl)

## -----------------------------------------------------------------------------
#  sql <- " SELECT bottle, 'total.counts', gated_density_perml FROM flowcytometer WHERE bottle = 29"
#  
#  tbl <- DBI::dbGetQuery(
#    conn,
#    statement = sql
#  )
#  head(tbl)

## -----------------------------------------------------------------------------
#  sql <- " SELECT flowcytometer.bottle, flowcytometer.gated_density_perml, manualcount.density FROM flowcytometer INNER JOIN manualcount ON flowcytometer.bottle = manualcount.bottle"
#  
#  tbl <- DBI::dbGetQuery(
#    conn,
#    statement = sql
#  )
#  head(tbl)

## -----------------------------------------------------------------------------
#  sql <- "
#  SELECT
#    flowcytometer.bottle,
#    flowcytometer.gated_density_perml,
#    manualcount.density
#  FROM
#    flowcytometer
#  INNER JOIN
#    manualcount
#  ON
#    flowcytometer.bottle = manualcount.bottle
#  "

## -----------------------------------------------------------------------------
#  DBI::dbDisconnect(conn)

