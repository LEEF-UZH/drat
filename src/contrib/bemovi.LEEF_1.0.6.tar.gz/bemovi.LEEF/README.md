Bemovi, software for extracting BEhaviour and MOrphology from VIdeos.
=============================================================================

Not recommended for usage - mod for use in LEEF!