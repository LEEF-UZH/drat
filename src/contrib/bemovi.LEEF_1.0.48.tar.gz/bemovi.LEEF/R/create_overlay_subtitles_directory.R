#' Function to create a single overlay by using ffmpeg and subtitles
#'
#' Function creates subtitle commands for each particle in every frame of the
#' videos, using the x/y coordinates. Then ffmpeg is called to burn the overlay
#' subtitles in the video, and save a compressed video as an mp4 file.
#' @param traj_data object containing the trajectory data (usually from the Master file)
#' @param avi_file_dir directory containing the input .avi files
#' @param parameter for croppoing rectangle to be drawn. An object as returned 
#'   by \code{par_crop_pixels()}
#' @param temp_overlay_folder  temporary directory to save the overlay subtitles
#'   (.ssa files). Defaults to a temporaty directory.
#' @param overlay_folder directory where the overlay video will be saved
#' @param overlay_type option for the overlays. Overlays can either be shown as
#'   \code{"label"}, \code{"circle"} or \code{"both"}
#' @param label column to be used to label the particle. Default is
#'   \code{"trajectory"}, other useful might be \code{"species"}
#' @param ffmpeg command to run ffmpeg. The default is \code{par_ffmpeg()}. It
#'   can include a path.
#' @param font_size size of the font for the labels. Default: 24
#' @param circle_size size of the circle. Default: 120
#' @param crf integer value between 1 to 51, where 1 means lossless, 17 is
#'   nearly visually lossless, 51 is worst quality. Default value is 23
#' @param gamma  gamma correction. Value between 0.1 and 10. Default 2. see
#'   \url{https://ffmpeg.org/ffmpeg-filters.html#eq} for further info
#' @param mc_cores number of cores toi be used for parallel execution. 
#'   Defaults to \code{par_mc.cores()}
#' 
#' @return returns invisibly the stderr and stdout of the ffmpeg invocations
#' @export

create_overlays_subtitle_directory <- function(
  traj_data,
  avi_file_dir,
  crop = par_crop_pixels(),
  temp_overlay_folder = tempfile(),
  overlay_folder = ".",
  overlay_type = "both",
  label = "trajectory",
  ffmpeg = "ffmpeg",
  font_size = 24,
  circle_size = 120,
  crf = 23,
  gamma = 2,
  mc_cores = par_mc.cores()
) {
  
  # Check if overlay type is valid
  if (!(overlay_type %in% c("circle", "label", "both"))) {
    stop("Wrong overlay type specified. Please choose 'circle', 'label', or 'both'")
  }
  
  # Make the folder to store the subtitle files, 
  # and generate the subtitle file
  dir.create(temp_overlay_folder, showWarnings = FALSE)
  
  # Create a folder to store the overlay videos
  dir.create(file.path(overlay_folder), showWarnings = FALSE)
  
  avi_files <- list.files(
    avi_file_dir,
    pattern = "\\.avi$", 
    full.names = TRUE, 
    recursive = FALSE
  )
  
  message("<<< BEGIN mclapply subtitles")
  message("    mc_cores = ", mc_cores)
  result <- parallel::mclapply(
    avi_files,
    function(avi_file) {
      create_overlays_subtitle_single(
        traj_data = traj_data[traj_data$file == gsub("\\.avi", "", basename(avi_file)), ],
        avi_file = avi_file,
        crop = crop,
        temp_overlay_folder = temp_overlay_folder,
        overlay_folder = overlay_folder,
        overlay_type = overlay_type,
        label = label,
        ffmpeg = ffmpeg,
        font_size = font_size,
        circle_size = circle_size,
        crf = crf,
        gamma = gamma
      )
    },
    mc.cores = mc_cores
  )
  message(">>> END mclapply subtitles")
  
  invisible(result)
}
