#' Function to create a single overlay by using ffmpeg and subtitles
#'
#' Function creates subtitle commands for each particle in every frame of the
#' videos, using the x/y coordinates. Then ffmpeg is called to burn the overlay
#' subtitles in the video, and save a compressed video as an mp4 file.
#' @param traj_data object containing the trajectory data (usually from the Master file)
#' @param avi_file input .avi file
#' @param parameter for croppoing rectangle to be drawn. An object as returned 
#'   by \code{par_crop_pixels()}
#' @param temp_overlay_folder  temporary directory to save the overlay subtitles
#'   (.ssa files). Defaults to a temporaty directory.
#' @param overlay_folder directory where the overlay video will be saved
#' @param overlay_type option for the overlays. Overlays can either be shown as
#'   \code{"label"}, \code{"circle"} or \code{"both"}
#' @param label column to be used to label the particle. Default is
#'   \code{"trajectory"}, other useful might be \code{"species"}
#' @param ffmpeg command to run ffmpeg. The default is \code{par_ffmpeg()}. It
#'   can include a path.
#' @param font_size size of the font for the labels. Default: 24
#' @param circle_size size of the circle. Default: 120
#' @param crf integer value between 1 to 51, where 1 means lossless, 17 is
#'   nearly visually lossless, 51 is worst quality. Default value is 23
#' @param gamma  gamma correction. Value between 0.1 and 10. Default 2. see
#'   \url{https://ffmpeg.org/ffmpeg-filters.html#eq} for further info
#' @return returns invisibly the stderr and stdout of the ffmpeg invocation
#' @export

create_overlays_subtitle_single <- function(
  traj_data,
  avi_file,
  crop = par_crop_pixels(),
  temp_overlay_folder = tempfile(),
  overlay_folder = ".",
  overlay_type = "both",
  label = "trajectory",
  ffmpeg = "ffmpeg",
  font_size = 24,
  circle_size = 120,
  crf = 23,
  gamma = 2
) {
  
  # Check if overlay type is valid
  if (!(overlay_type %in% c("circle", "label", "both"))) {
    stop("Wrong overlay type specified. Please choose 'circle', 'label', or 'both'")
  }
  
  # Make the folder to store the subtitle files, 
  # and generate the subtitle file
  dir.create(temp_overlay_folder, recursive = TRUE, showWarnings = FALSE)
  
  # Create a folder to store the overlay videos
  dir.create(file.path(overlay_folder), recursive = TRUE, showWarnings = FALSE)
  
  aviname <- gsub("\\.avi$", "", (basename(avi_file)))
  traj_data <- traj_data[traj_data$file == aviname, ]
  
  # get fps for all avi files and add to traj_data
  fps <- get_fps_avi(avi_file, ffmpeg = ffmpeg, mc.cores = 1)
  
  # get duration for all avi files and add to traj_data
  duration <- get_duration_avi(avi_file, ffmpeg = ffmpeg, mc.cores = 1)
  
  # get width for all avi files and add to  <- 
  width <- get_width_avi(avi_file, ffmpeg = ffmpeg, mc.cores = 1)
  
  # get height for all avi files and add to traj_data
  height <- get_height_avi(avi_file, ffmpeg = ffmpeg, mc.cores =1)

  if (nrow(traj_data) > 0){
    
    # Define in the filtered trajectory data the start and end time of each observation,
    # as well as the numeric ID of the observation
    traj_data$starttime <- traj_data$frame * (1 / fps)
    traj_data$endtime <- traj_data$starttime + (1 / fps)
    
    #  Generate the header for the subtitle file
    
    traj_data$header <- paste0(
      "[Script Info]",  "\n",
      "ScriptType: v4.00+",  "\n",
      "Collisions: Normal", "\n",
      "PlayResX: ", width, "\n",
      "PlayResY: ", height, "\n",
      "Timer: ", duration, "\n",
      "\n",
      "[V4+ Styles]", "\n",
      "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour,",
      " Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle,",
      " BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding", "\n",
      "Style: Label,Arial,", font_size, ",65535,65535,65535,65535,0,0,0,0,100,100,0,0.00,1,1,0,2,0,0,0,0", "\n",
      "Style: Circle,Arial,", circle_size, ",&H0000FF,&H0000FF,&H0000FF,&H0000FF,0,0,0,0,100,100,0,0.00,1,1,0,2,0,0,0,0", "\n",
      "\n",
      "[Events]", "\n",
      "Format: Layer, Start, End, Style, Actor, MarginL, MarginR, MarginV, Effect, Text", "\n"
    )
    
    # Generate a subtitle line for each observation
    traj_data$subtitle_label <- paste0(
      "Dialogue: 2,0:00:", sprintf("%05.2f", traj_data$starttime), ",0:00:", sprintf("%05.2f", traj_data$endtime),
      ",Label,,0000,0000,0000,,",
      "{\\pos(",
      abs(round(traj_data$X)), ", ",
      abs(round(traj_data$Y + circle_size / 2)),
      ")}",
      traj_data[[label]]
    )
    traj_data$subtitle_circle <- paste0(
      "Dialogue: 1,0:00:", sprintf("%05.2f", traj_data$starttime), ",0:00:", sprintf("%05.2f", traj_data$endtime),
      ",Circle,,0000,0000,0000,,",
      "{\\pos(",
      abs(round(traj_data$X)), ", ",
      ifelse(
        abs(round(traj_data$Y)) < height,
        abs(round(traj_data$Y)) + circle_size / 2,
        abs(round(traj_data$Y))
      ),
      ")}",
      "O"
    )
    
    # Generate the subtitle file
    
    message("BEGIN generating subtitles for ", aviname)
    if (overlay_type == "circle") {
      ssa <- c(
        traj_data[1, "header"][[1]],
        unlist(traj_data[, "subtitle_circle"])
      )
    } else if (overlay_type == "label") {
      ssa <- c(
        traj_data[1, "header"][[1]],
        unlist(traj_data[, "subtitle_label"])
      )
    } else if (overlay_type == "both") {
      ssa <- c(
        traj_data[1, "header"][[1]],
        unlist(traj_data[, "subtitle_label"]),
        unlist(traj_data[, "subtitle_circle"])
      )
    }
    ssa_file <- file.path(temp_overlay_folder, paste0(aviname, ".ssa"))
    writeLines(
      ssa,
      ssa_file
    )
    message("END generating subtitles for ", aviname)
    
    # Burn the subtitles into the avi file,
    # and store the resulting file in the overlay folder
    
  }
  message("BEGIN BurnIn ", aviname)
  avi_file <- normalizePath(avi_file)
  ssa_file <- normalizePath(ssa_file)
  mp4_file <-  normalizePath(
    file.path(
      overlay_folder, 
      paste0(aviname, ".mp4")
    ),
    mustWork = FALSE
  )
  
  cf <- fix_crop_pixels(crop)
  cf[["xmax"]][is.infinite(cf[["xmax"]])] <- as.numeric(width)
  cf[["ymax"]][is.infinite(cf[["ymax"]])] <- as.numeric(height)
  
  if (nrow(traj_data) > 0) {
    arguments <- paste0(
      " -i '", avi_file, "'",
      " -vf ",
      " '",
      "ass=", ssa_file, ",",
      "drawbox=x=", cf$xmin, ":y=", cf$ymin, ":w=", cf$xmax - cf$xmin, ":h=", cf$ymax - cf$ymin, ":color=red", ",",
      "eq=gamma=", gamma,
      "'",
      " -vcodec libx264",
      " -preset medium",
      " -pix_fmt yuv420p",
      " -crf ", crf,
      " -y '", mp4_file, "'"
    )
  } else {
    arguments <- paste0(
      " -i '", avi_file, "'",
      " -vf ",
      " '",
      "drawbox=x=", cf$xmin, ":y=", cf$ymin, ":w=", cf$xmax - cf$xmin, ":h=", cf$ymax - cf$ymin, ":color=red", ",",
      "eq=gamma=", gamma,
      "'",
      " -vcodec libx264",
      " -preset medium",
      " -pix_fmt yuv420p",
      " -crf ", crf,
      " -y '", mp4_file, "'"
    )
  }
  result <- system2(
    command = ffmpeg,
    args = arguments,
    stdout = TRUE,
    stderr = TRUE,
  )
  message(" END BurnIn ", aviname)
  
  invisible(result)
}
