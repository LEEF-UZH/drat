#' Function to make overlays using the subtitle files,
#'
#' Function creates subtitle commands for every particle in every frame of the videos, using the x/y coordinates.
#' Then ffmpeg is called to burn the overlay subtitles on, and save a compressed video as an mp4 file.
#' @param to.data path to the working directory
#' @param merged.data.folder directory where the global database is saved relative to the \code{to.data} directy
#' @param raw.avi.folder path to the folder containing the converted and compressed .avi files relative to the \code{to.data} directy
#' @param temp.overlay.folder  temporary directory to save the overlay subtitles (.ssa files) relative to the \code{to.data} directy
#' @param overlay.folder directory where the overlay videos are saved relative to the \code{to.data} directly
#' @param label column to be used to label the particle.
#'   Default is \code{"trajectory"}, other useful might be \code{"species"}
#' @param ffmpeg command to run ffmpeg. The default is \code{par_ffmpeg()}. It can include a path.
#' @param master name of the master file. Defaults to \code{par_master()}
#' @param overlay.type option for the overlays. Overlays can either be shown as \code{"label"}, \code{"circle"} or \code{"both"}
#' @param font_size size of the font for the labels. Default: 24
#' @param circle_size size of the circle. Default: 120
#' @param crf integer value between 1 to 51, where 1 means lossless, 17 is nearly visually lossless, 
#'    51 is worst quality. Default value is 23
#' @param gamma  gamma correction. Value between 0.1 and 10. Default 2. see \url{https://ffmpeg.org/ffmpeg-filters.html#eq} 
#'    for further info
#' @param mc.cores number of cores toi be used for parallel execution. Defaults to \code{par_mc.cores()}
#' 
#' @return returns invisibly the stderr and stdout of the ffmpeg invocations
#' @importFrom data.table fwrite
#' @export

create_overlays_subtitle_new <- function(
  to.data = par_to.data(),
  merged.data.folder = par_merged.data.folder(),
  raw.video.folder = par_raw.video.folder(),
  temp.overlay.folder = par_temp.overlay.folder(),
  overlay.folder = par_overlay.folder(),
  label = "trajectory",
  ffmpeg = par_ffmpeg(),
  ## new arguments
  master = par_master(),
  overlay.type = "both",
  font_size = 24,
  circle_size = 120,
  crf = 23,
  gamma = 2,
  mc.cores = par_mc.cores()
) {
  # Check if overlay type is valid
  if (!(overlay.type %in% c("circle", "label", "both"))) {
    stop("Wrong overlay type specified. Please choose 'circle', 'label', or 'both'")
  }
  
  result <- create_overlays_subtitle_directory <- function(
    traj_data = readRDS(file = file.path(to.data, merged.data.folder, master)),
    avi_file_dir = file.path(raw.video.folder),
    crop = par_crop_pixels(),
    temp_overlay_folder = temp.overlay.folder,
    overlay_folder = overlay.folder,
    overlay_type = overlay.type,
    label = label,
    ffmpeg = ffmpeg,
    font_size = font_size,
    circle_size = circle_size,
    crf = crf,
    gamma = gamma,
    mc_cores = mc.cores
  )

  invisible(result)
}
