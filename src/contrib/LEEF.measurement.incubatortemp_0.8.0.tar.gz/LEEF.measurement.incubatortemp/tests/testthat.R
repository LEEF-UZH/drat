library(testthat)
library(LEEF.measurement.incubatortemp)

test_check("LEEF.measurement.incubatortemp")
