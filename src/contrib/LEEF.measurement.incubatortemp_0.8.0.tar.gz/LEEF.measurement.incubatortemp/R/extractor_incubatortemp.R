#' Extractor incubatortemp data
#'
#' Convert all \code{.cvs} files in \code{incubatortemp} folder to \code{data.frame} and save as \code{.rds} file.
#'
#' This function is extracting data to be added to the database (and therefore make accessible for further analysis and forecasting)
#' from \code{.csv} files.
#'
#' @param input directory from which to read the data
#' @param output directory to which to write the data
#'
#' @return invisibly \code{TRUE} when completed successful
#'
#' @importFrom dplyr bind_rows
#' @importFrom readr read_file locale read_tsv
#' @export
#'
extractor_incubatortemp <- function(
  input,
  output )
{
  message("\n########################################################\n")
  message("\nExtracting Incubatortemp\n")

  # Get csv file names ------------------------------------------------------

  incubatortemp_path <- file.path( input, "incubatortemp" )
  incubatortemp_files <- list.files(
    path = incubatortemp_path,
    pattern = "*.txt",
    full.names = TRUE,
    recursive = TRUE
  )

  if (length(incubatortemp_files) == 0) {
    message("nothing to extract\n")
    message("\n########################################################\n")
    return(invisible(FALSE))
  }

# Read file ---------------------------------------------------------------

  itmp <- lapply(
    incubatortemp_files,
    function(fn) {
      data <- readr::read_file( fn, locale = readr::locale(encoding = "UTF-16LE") )
      data <- readr::read_tsv( data )
      return(data)
    }
  )
  # combine intu one large tibble
  itmp <- dplyr::bind_rows(itmp)

# SAVE --------------------------------------------------------------------

  add_path <- file.path( output, "incubatortemp" )
  dir.create( add_path, recursive = TRUE, showWarnings = FALSE  )
  saveRDS(
    object = itmp,
    file = file.path(add_path, "incubatortemp.rds")
  )

# Finalize ----------------------------------------------------------------

  message("done\n")
  message("\n########################################################\n")

  invisible(TRUE)
}
