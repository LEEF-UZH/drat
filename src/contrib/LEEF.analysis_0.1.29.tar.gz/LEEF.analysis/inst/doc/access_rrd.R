## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = TRUE
)

## ----install, eval = FALSE----------------------------------------------------
#  if (!require("drat")) {
#    install.packages("drat")
#    library(drat)
#  }
#  drat::addRepo("LEEF-UZH")
#  install.packages("LEEF.analysis")

## ----setup--------------------------------------------------------------------
library(LEEF.analysis)
library(dplyr)

## -----------------------------------------------------------------------------
options(RRDdb = "/Volumes/LEEF/0.RRD/LEEF.RRD.sqlite")

## -----------------------------------------------------------------------------
db_read_density()

## -----------------------------------------------------------------------------
db_read_density() %>%
  collect()

## -----------------------------------------------------------------------------
system.time(
  x <- db_read_density() %>%
    select(timestamp, day) %>%
    distinct() %>%
    collect()
)
x

## -----------------------------------------------------------------------------
system.time(
  x <- db_read_density() %>%
    collect() %>%
    select(timestamp, day) %>%
    distinct()
)
x

## -----------------------------------------------------------------------------
db_read_o2()


## -----------------------------------------------------------------------------
read_sql(sql = "SELECT * FROM density") %>%
    filter (as.integer(timestamp) >= as.integer(20210920)) %>%
    filter (as.integer(timestamp) <= as.integer(21000101))

## -----------------------------------------------------------------------------
db_read_density() %>%
  collect()

