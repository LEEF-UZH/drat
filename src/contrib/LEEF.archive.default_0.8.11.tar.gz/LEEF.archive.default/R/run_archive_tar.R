#' Compress and checksum the \code{DATA_options("new_data_path")}
#'
#' @return \code{run_archive_tar()}: invisibly returns the name of the archive file
#' @importFrom openssl sha256
#' @importFrom utils tar
#'
#' @rdname run_archive
#'
#' @export
#'
#' @examples
#' \dontrun{
#' run_archive.tar(
#'   input = "./input",
#'   output = "./output"
#' )
#' }
run_archive_tar <- function(
  input,
  output
){
  input <- file.path(input, ".")

  oldwd <- getwd()
  on.exit(
    setwd(oldwd)
  )
  ##
  tmpdir <- file.path(output, "tmp_tar")

  input <- run_archive_none( input = input, output = file.path(tmpdir, "tmp_none") )
  ##
  archivename <- normalizePath(
    paste(
      basename(input),
      "tar",
      sep = "."
    ),
    mustWork = FALSE
  )

  dir.create(tmpdir, recursive = TRUE, showWarnings = FALSE)

  tarfile <- file.path( tmpdir, archivename)

  ##

# Tar input directory -----------------------------------------------------

  oldwd <- setwd(dirname(input))
  utils::tar(
    tarfile = tarfile,
    files = "./"
  )
  setwd(oldwd)

# Hash tar file -----------------------------------------------------------

  f <- file( tarfile, open = "rb" )
  hash <- as.character( openssl::sha256( f ) )
  close(f)
  rm(f)
  hashln <- paste(hash, archivename, sep = "  ")
  hashfile <- paste0(tarfile, ".sha256")
  file.create(hashfile)
  f <- file( hashfile )
  writeLines(
    text = hashln,
    con = f
  )
  close(f)
  rm(f)

# Copy to output ----------------------------------------------------------

  dir.create( path = output, showWarnings = FALSE, recursive = TRUE )
  ##
  file.copy(
    from = c(tarfile, hashfile),
    to = output,
    copy.date = TRUE
  )

  unlink(tmpdir, recursive = TRUE)
  unlink(file.path(output, "tmp_none"), recursive = TRUE)

# Return ------------------------------------------------------------------

  invisible( file.path( output, archivename ) )
}
