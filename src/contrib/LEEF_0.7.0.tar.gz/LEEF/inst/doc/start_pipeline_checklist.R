## ----setup--------------------------------------------------------------------
knitr::opts_chunk$set(
	collapse = TRUE,
	comment = "#>",
	include = FALSE
)
library(LEEF)

