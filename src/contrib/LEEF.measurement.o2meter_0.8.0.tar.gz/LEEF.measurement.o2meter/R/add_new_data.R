#' Check if data in input folder is OK and move to raw data folder
#'
#' @param input The folder, where a folder \code{o2meter} is located which
#'   contains the new files.
#' @param output A folder, which contains a subfolder called \code{o2meter}, i.e.
#'   the usually the raw data folder, into which the files will be moved to.
#'
#' @return a \code{list} which contains the individual results for each file.
#'   \code{TRUE} if moved, \code{FALSE} if an error occurred. Details of the error
#'   are in the error files in the \code{input/o2meter} directory.
#' @importFrom parallel mclapply
#' @export
#'
add_new_data <- function(input, output) {
  ##
  dir.create(
    file.path(output, "o2meter"),
    showWarnings = FALSE,
    recursive = TRUE
  )

  # Copy ALL other files ----------------------------------------------------

#   others <- grep(
#     list.files(
#       path = input,
#       full.names = TRUE
#     ),
#     pattern='.cxd',
#     invert=TRUE,
#     value=TRUE
#   )
#   file.copy(
#     from = others,
#     to = file.path(output, "bemovi"),
#     overwrite = TRUE
#   )
#   unlink( others )

  # Check and move folder ------------------------------------------------------

  files <- list.files(
    path = input,
    pattern = "\\.csv",
    full.names = FALSE
  )

  ##
  ok <- parallel::mclapply(
    files,
    function(f) {
      processing <- file.path(input, paste0("CHECKING.", f, ".CHECKING"))
      error <- file.path(input, paste0("ERROR.", f, ".txt"))

      on.exit(
        {
          if (file.exists(processing)) {
            unlink(processing)
            capture.output(print(result), file = error)
          }
        }
      )
      ##
      file.create( processing )
      ##
      message("checking ", f)
      result <- list(
        ok = TRUE
      )

      # Check if file exist ----------------------------------------------------------

      ok <- list()

      ok$version <- readLines(file.path(input, f), encoding = "ISO-8859-1", n = 1) == "Exported with PreSens Datamanager V2.0.0.57"
      ok$header <- readLines(file.path(input, f), encoding = "ISO-8859-1", n = 2)[[2]] == "Date;Time;User;SensorID;SensorName;delta_t;Unit;Value;Unit;Mode;Phase;Unit;Amplitude;Unit;Temp;Unit;patm;Unit;Salinity;Unit;Error;Cal0;Unit;T0;Unit;O2-2nd;Unit;Cal2nd;Unit;T2nd;Unit;CalPressure;Unit;f1;dPhi1;dkSv1;dPhi2;dkSv2;m;Cal Mode;SignalLEDCurrent;ReferenceLEDCurrent;ReferenceAmplitude;DeviceSerial;FwVersion;SensorType;BatchID;Calibration Date;Sensor lot;PreSens calibrated Sensor;Battery Voltage;Unit"

      x <- read.delim(
        file = file.path(input, f),
        sep = ";",
        skip = 1,
        header = FALSE,
        fill = TRUE,
        stringsAsFactors = FALSE,
        strip.white = TRUE,
        fileEncoding = "ISO-8859-1"
      )

      ok$data <- nrow(x) >= 1

      result$ok <- all(unlist(result))

      if ( result$ok ) {
        file.copy(
          from = file.path(input, f),
          to = file.path(output, "o2meter"),
          recursive = FALSE,
          overwrite = TRUE
        )
        unlink( file.path(input, f) )
        unlink(processing)
      }
      return(result)
    }
  )
  names(ok) <- files
  return(ok)
}

