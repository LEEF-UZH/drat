library(testthat)
library(LEEF.measurement.o2meter)

test_check("LEEF.measurement.o2meter")
